﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 역설계
{
    internal class sleepdata
    {
        public string date { get; set; }
        public string heart { get; set; }
        public string moving { get; set; }
        public string sleep_apena { get; set; }
    }
}
