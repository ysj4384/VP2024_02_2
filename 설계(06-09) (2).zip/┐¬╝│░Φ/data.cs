﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 역설계
{
    internal class data
    {
        public int heart { get; set; }
        public double moving { get; set; }
        public int sleep_apena { get; set; }
        public string date {  get; set; }
        public string heartstate { get; set; }
        public string movingstate { get; set; }
        public string spstate { get; set; }
        public string time {  get; set; }
    }
}
