﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M.I.E_alpha_ver._
{
    internal class User
    {
        public string id {  get; set; }
        public string password { get; set; }
    }
}
