﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M.I.E_alpha_ver._
{
    public partial class Form5 : Form
    {
        public List<string> databaseanswer { get; set; } //유저의 답변리스트
        public List<string> choicequestion { get; set; } //로그인한 유저 ID
        public Form5()
        {
            InitializeComponent();
        }
        List<string> result = new List<string>();
        private void Form5_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < choicequestion.Count; i++)
            {
                result.Add("질문 : " + choicequestion[i] + "\n" +"답변 : " + databaseanswer[i] + "\n\n");
            }
            label1.Text = string.Join(Environment.NewLine, result);
        }
    }
}
