﻿using FireSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using static FireSharp.FirebaseClient;
using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.CognitiveServices.Speech;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.CognitiveServices.Speech.Transcription;
using System.Security.Policy;
using System.Speech.Synthesis;
using System.Windows.Forms;

namespace M.I.E_alpha_ver._
{
    public partial class Form3 : Form
    {
        public string userID { get; set; } //로그인한 유저 ID
        public List<string> choicequestion { get; set; } //유저가 선택한 질문리스트
        
        // 질문 답변 저장을 위한 클라이언트
        private Firebase.Database.FirebaseClient firebaseclient;

        // TTS 설정
        private System.Speech.Synthesis.SpeechSynthesizer synthesizer = new System.Speech.Synthesis.SpeechSynthesizer();
        private bool isRecognizing = false;

        //STT 설정
        private SpeechRecognizer recognizer;

        int questionindex = 1;

        public Form3()
        {
            InitializeComponent();
            //TTS 세부설정
            synthesizer.SetOutputToDefaultAudioDevice();
            synthesizer.SelectVoice("Microsoft Heami Desktop");
            //질문 등록을 위한 파이어 베이스 초기화
            firebaseclient = new Firebase.Database.FirebaseClient("https://mie-db-default-rtdb.firebaseio.com/");

        }

        private void buttonnext_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            recognizer.StopContinuousRecognitionAsync().Wait();

            //리스트에 추가된 선택된 질문들을 순서대로 TTS로 출력
            if (questionindex < choicequestion.Count)
            {
                textBox1.Text = choicequestion[questionindex];
                synthesizer.Speak(textBox1.Text); // TTS 출력

                UploadQeustionToFirebase(choicequestion[questionindex]);
                questionindex++;
            }
            else
            {
                MessageBox.Show("질문이 끝났습니다.");
                buttonnext.Enabled = false;
            }
        }

        private string currentQuestionKey;
        private async void UploadQeustionToFirebase(string Q)
        {
            var dataObject = new { 질문 = Q };
            try
            {
                currentQuestionKey = (await firebaseclient
            .Child($"User/{userID}/Question")
            .PostAsync(dataObject)).Key;
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 업로드 실패: " + ex.Message);
            }
        }

        private async void buttonanswer_Click(object sender, EventArgs e)
        {
            //STT 세부 설정
            var config = SpeechConfig.FromSubscription("3ea489fc76a14cf7bf9dbf6ecad323b0", "koreacentral");
            config.SpeechRecognitionLanguage = "ko-KR";
            recognizer = new SpeechRecognizer(config);
            textBox2.Clear();
            isRecognizing = true;

            recognizer.Recognized += Recognizer_Recognized;
            await recognizer.StartContinuousRecognitionAsync();
        }

        private void Recognizer_Recognized(object sender, SpeechRecognitionEventArgs e)
        {
            if (e.Result.Reason == ResultReason.RecognizedSpeech)
            {

                if (textBox1.InvokeRequired)
                {
                    textBox1.Invoke(new Action(() =>
                    {
                        textBox2.Clear();
                        textBox2.AppendText(e.Result.Text + "\n");
                        UploadAnswerToFirebase(e.Result.Text);
                    }));
                }
                else
                {
                    textBox2.Clear();
                    textBox2.AppendText(e.Result.Text + "\n");
                    UploadAnswerToFirebase(e.Result.Text);
                }
            }
            else if (e.Result.Reason == ResultReason.NoMatch)
            {
                if (textBox2.InvokeRequired)
                {
                    textBox2.Invoke(new Action(() =>
                    {
                        textBox2.AppendText("음성을 인식할 수 없습니다.\n");
                    }));
                }
                else
                {
                    textBox2.AppendText("음성을 인식할 수 없습니다.\n");
                }
            }
        }

        List<string> databaseanswer = new List<string>();
        private string currentAnswerKey;
        private async void UploadAnswerToFirebase(string A)
        {
            var dataObject = new { 답변 = A };
            try
            {
                currentAnswerKey = (await firebaseclient
            .Child($"User/{userID}/Question/{currentQuestionKey}")
            .PostAsync(dataObject)).Key;
                databaseanswer.Add(A.ToString());
                //MessageBox.Show("데이터 업로드 성공: " + A);
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 업로드 실패: " + ex.Message);
            }
        }

        private void buttoncheck_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            form5.databaseanswer = databaseanswer;
            form5.choicequestion = choicequestion;
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBox1.Text = choicequestion[0];
            synthesizer.Speak(textBox1.Text); // TTS 출력
            UploadQeustionToFirebase(choicequestion[0]);
        }
    }
}
