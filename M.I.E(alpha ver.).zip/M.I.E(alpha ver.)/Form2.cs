﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace M.I.E_alpha_ver._
{
    public partial class Form2 : Form
    {
        //로그인한 유저 ID
        public string userID { get; set; }

        //면접 질문 리스트
        private List<String> basic;
        private List<String> marketing;
        private List<String> personnel;
        private List<String> plan;
        private List<String> sales;
        private List<String> developer;
        private List<String> datawork;
        private List<String> engineer;

        //유저가 선택한 직종의 질문을 저장할 리스트
        List<String> choicequestion = new List<string>();
        public Form2()
        {
            InitializeComponent();

            //질문 설정 메소드
            InitializeQeustionList();
        }

        private void InitializeQeustionList()
        {
            //기본 질문
            basic = new List<string> {
                "자기 소개 해보세요",
                "자신의 강점과 단점은 무엇인가요?",
                "이 직무를 선택한 이유는 무엇인가요?",
                "이 회사에 지원한 이유는 무엇인가요?"
            };
            //마케팅 직무 질문
            marketing = new List<string> {
                "마케팅 분야에서 가장 중요하다고 생각하는 트렌드는 무엇이며, 왜 그렇게 생각하나요?",
                "우리 브랜드를 어떻게 개선하거나 성장시킬 수 있는지 구체적인 전략을 제시해주세요",
                "지금까지 진행한 마케팅 캠페인 중 가장 성공적이었다고 생각하는 것은 무엇인가요, 그리고 그 이유는 무엇인가요?",
                "소셜 미디어 마케팅의 효과를 어떻게 측정할 수 있나요?",
                "당신이 생각하는 실패한 마케팅 캠페인 사례는 무엇이며, 그 원인은 무엇이라고 생각하나요?",
                "마케팅 트렌드 중 하나를 선택하고, 이 트렌드가 우리 회사에 어떻게 적용될 수 있는지 설명해 주세요.",
                "가장 선호하는 마케팅 도구나 소프트웨어는 무엇이며, 왜 그렇게 생각하나요?",
                "효과적인 컨텐츠 마케팅 전략은 무엇이라고 생각하나요?",
                "마케팅 데이터를 분석할 때 어떤 지표들을 주로 고려하나요?"
            };
            //인사 직무 질문
            personnel = new List<string> {
                "인사 관리에서 가장 중요하다고 생각하는 요소는 무엇이며, 그 이유는 무엇인가요?",
                "조직 문화를 개선하기 위해 구체적으로 어떤 전략을 사용하겠습니까?",
                "직원 성과 관리를 어떻게 접근하고, 어떤 도구를 사용하나요?",
                "직원 이직률을 줄이기 위한 전략은 무엇이며, 그 전략의 효과는 어떻게 평가하나요?",
                "최근에 직면했던 HR 관련 도전과제는 무엇이었으며, 어떻게 해결했나요?",
                "인사팀과 다른 부서 간의 협력을 어떻게 강화할 계획인가요?",
                "채용 프로세스를 개선하기 위해 어떤 노력을 기울일 것인가요?",
                "직원의 동기 부여와 직무 만족도를 높이는 데 있어 가장 효과적인 전략은 무엇이라고 생각하나요?",
                "인사 관리에서 데이터 분석의 역할은 어떻게 보나요, 그리고 어떻게 활용하나요?"
            };
            //기획 직무 질문
            plan = new List<string>
            {
                "당신이 생각하는 IT 기획의 가장 중요한 요소는 무엇이며, 왜 그렇게 생각하나요?",
                "과거에 참여한 IT 프로젝트 중 가장 성공적이었다고 생각하는 프로젝트는 무엇이며, 그 이유는 무엇인가요?",
                "프로젝트 예산 초과를 방지하기 위한 전략은 무엇인가요?",
                "대규모 IT 프로젝트를 계획할 때 가장 큰 도전을 무엇이었고, 어떻게 극복했나요?",
                "팀과의 커뮤니케이션을 어떻게 관리하나요? 효과적인 커뮤니케이션을 위한 전략에는 무엇이 포함되나요?",
                "기술적 문제 해결을 위해 접근하는 방식을 구체적인 예를 들어 설명해 주세요.",
                "프로젝트의 범위가 중간에 변경될 때 어떻게 대응하나요?",
                "IT 프로젝트 기획에서 가장 선호하는 프로젝트 관리 도구는 무엇이며, 그 이유는 무엇인가요?",
                "지금까지의 경험에서 배운 IT 프로젝트 관리의 가장 중요한 교훈은 무엇인가요?"
            };
            //영업 직무 질문
            sales = new List<string>
            {
                "영업 직무에 지원한 동기와 이 직무가 자신에게 적합하다고 생각하는 이유는 무엇인가요?",
                "지금까지 달성한 가장 큰 영업 성공 사례를 소개해 주세요. 그 과정에서 어떤 전략을 사용했나요?",
                "고객의 구매 결정 과정을 어떻게 이해하고, 이를 기반으로 어떻게 영업 전략을 수립하나요?",
                "어려운 고객을 만났을 때, 그 상황을 어떻게 관리할 것인가요?",
                "신제품이나 서비스를 시장에 소개할 때, 어떤 접근 방식을 사용하나요?",
                "경쟁사 제품과 비교했을 때 우리 제품의 강점과 약점은 무엇이라고 생각하나요?",
                "팀 영업 환경에서 다른 팀원들과 어떻게 협력하나요? 효과적인 팀워크를 위해 중요하다고 생각하는 요소는 무엇인가요?",
                "시장 동향과 고객의 니즈를 어떻게 파악하나요? 정보를 수집하고 분석하는 과정을 설명해 주세요.",
                "자신이 관리하는 영업 파이프라인을 어떻게 관리 할 것인가요? 우선 순위를 설정하고 결과를 모니터링 하는 방법에 대해 설명해 주세요."
            };
            //개발 직무 질문
            developer = new List<string> {
                "최근에 작업한 프로젝트에서 사용한 프로그래밍 언어와 기술 스택은 무엇인가요?",
                "객체지향 프로그래밍의 주요 원칙에 대해 설명해 주세요.",
                "코드 리뷰의 중요성에 대해 어떻게 생각하나요?",
                "효율적인 디버깅 전략은 무엇이라고 생각하나요?",
                "대규모 시스템 설계 경험이 있다면, 그 과정에서 가장 중요하게 고려한 점은 무엇이었나요?",
                "Agile 개발 방법론에 대해 어떻게 생각하나요?",
                "RESTful API 설계 시 고려해야 할 주요 사항은 무엇인가요?",
                "성능 최적화를 위해 어떤 기술이나 방법을 사용했나요?",
                "Git 같은 버전 관리 시스템을 사용할 때의 장점은 무엇이라고 생각하나요?",
                "컨테이너화(예: Docker)가 가지는 이점에 대해 설명해 주세요.",
                "단위 테스트의 중요성에 대해 설명해 주세요.",
                "최근에 관심을 가지고 있는 새로운 프로그래밍 언어나 기술은 무엇인가요?"
            };
            //데이터 직무 질문
            datawork = new List<string>
            {
                "가장 성공적이었다고 생각하는 데이터 분석 프로젝트는 무엇인가요?",
                "결측치를 처리하는 여러 방법에 대해 설명해 주세요.",
                "과적합을 방지하는 기술에는 어떤 것들이 있나요?",
                "머신 러닝 모델을 평가할 때 사용하는 주요 지표는 무엇인가요?",
                "대용량 데이터를 처리하는 데 사용한 경험이 있는 툴이나 프레임워크는 무엇인가요?",
                "A/B 테스팅의 중요성에 대해 설명해 주세요.",
                "피처 엔지니어링의 중요성에 대해 설명해 주세요.",
                "최근에 집중하고 있는 머신 러닝이나 딥러닝의 트렌드는 무엇인가요?",
                "시계열 데이터 분석에서의 주요 과제는 무엇이라고 생각하나요?",
                "모델의 해석 가능성을 높이기 위해 어떤 방법을 사용했나요?",
                "큰 데이터 세트에서 유의미한 인사이트를 도출한 경험에 대해 설명해 주세요.",
                "데이터 과학 프로젝트에서 실패한 경험에 대해 설명하고, 그로부터 어떤 교훈을 얻었나요?"
            };
            //엔지니어 직무 질문
            engineer = new List<string> 
            {
                "가장 도전적이었던 기계 설계 프로젝트는 무엇이었나요, 그리고 어떻게 해결했나요?",
                "CAD 소프트웨어를 사용한 경험에 대해 설명해 주세요.",
                "기계적 실패를 분석하고 해결하기 위한 당신의 접근 방식은 무엇인가요?",
                "열역학의 원리를 실제 설계에 어떻게 적용했나요?",
                "진동 분석에 대한 당신의 경험은 어떤가요?",
                "제품 개발 과정에서 기능성과 비용 효율성 사이에서 어떻게 균형을 맞췄나요?",
                "최신 제조 기술 중 어떤 기술에 가장 관심이 있나요, 그리고 그 이유는 무엇인가요?",
                "프로젝트 관리 경험에 대해 설명해 주세요. 어떤 도구나 방법론을 사용했나요?",
                "팀 프로젝트에서 겪은 가장 큰 어려움은 무엇이었고, 어떻게 극복했나요?",
                "유체 역학을 실제 설계 문제에 어떻게 적용했나요?",
                "기계 시스템에서 에너지 효율성을 개선하기 위한 전략은 무엇인가요?",
                "최근 기계 엔지니어링 분야에서 관심을 가지고 있는 연구 주제나 기술은 무엇인가요?"
            };

        }
        private void startbutton_Click(object sender, EventArgs e)
        {
            String log = "선택한 직종 : ";
            if (checkBoxbasic.Checked == true)
            {
                choicequestion.AddRange(basic);
                log += "기본 ";
            }
            if (checkBoxmarketing.Checked == true)
            {
                choicequestion.AddRange(marketing);
                log += "마케팅 ";
            }
            if (checkBoxpersonnel.Checked == true)
            {
                choicequestion.AddRange(personnel);
                log += "인사 직무, ";
            }
            if (checkBoxplan.Checked == true)
            {
                choicequestion.AddRange(plan);
                log += "기획 직무, ";
            }
            if (checkBoxsales.Checked == true)
            {
                choicequestion.AddRange(sales);
                log += "영업 직무, ";
            }
            if (checkBoxdevelop.Checked == true)
            {
                choicequestion.AddRange(developer);
                log += "개발 직무, ";
            }
            if (checkBoxdata.Checked == true)
            {
                choicequestion.AddRange(datawork);
                log += "데이터 직무, ";
            }
            if (checkBoxengineer.Checked == true)
            {
                choicequestion.AddRange(engineer);
                log += "엔지니어 직무, ";
            }

            if(checkBoxnewbie.Checked == true)
            {
                Form3 form3 = new Form3();
                form3.userID = userID;
                form3.choicequestion = choicequestion;
                form3.Show();
            }
            if (checkBoxexpert.Checked == true)
            {
                Form4 form4 = new Form4();
                form4.userID = userID;
                form4.choicequestion = choicequestion;
                form4.Show();
            }
            MessageBox.Show(log);

            
            this.Hide();
        }
    }
}
