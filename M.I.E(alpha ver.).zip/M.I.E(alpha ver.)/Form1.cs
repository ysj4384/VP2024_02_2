﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Windows.Forms;

namespace M.I.E_alpha_ver._
{
    public partial class Form1 : Form
    {
        // 로그인 파이어 베이스 연동
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "X9R3DSvEB25tx8S6LRdxaWvqSKYBQSypyeYPFFc3",
            BasePath = "https://mie-db-default-rtdb.firebaseio.com/"
        };

        // 로그인을 위한 클라이언트
        IFirebaseClient client;

        //로그인한 유저
        string userID;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 로그인 DB 초기화
            client = new FireSharp.FirebaseClient(config);
        }

        private async void buttonjoin_Click(object sender, EventArgs e)
        {
            var data = new User
            {
                id = textBoxid.Text,
                password = textBoxpass.Text
            };

            try
            {
                var response = await client.GetAsync("User/" + textBoxid.Text); // "User/{id}" 경로로 데이터 조회
                
                if (response.Body != "null") // ID가 이미 존재하는 경우
                {
                    MessageBox.Show("이미 존재하는 아이디입니다.");
                }
                else // 중복된 ID가 없으면, SetAsync로 새로운 데이터 추가
                {
                    SetResponse setResponse = await client.SetAsync("User/" + textBoxid.Text, data);

                    if (setResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        MessageBox.Show("회원가입 성공!");
                    }
                    else
                    {
                        MessageBox.Show("회원가입 중 오류가 발생했습니다.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"오류 발생: {ex.Message}");
            }
        }

        private async void buttonlogin_Click(object sender, EventArgs e)
        {
            string userId = textBoxid.Text;
            string userPassword = textBoxpass.Text;
            Form2 form2 = new Form2();

            FirebaseResponse response = await client.GetAsync("User/" + userId);
            User existingUser = response.ResultAs<User>();

            if (existingUser != null && existingUser.password == userPassword)
            {
                MessageBox.Show("로그인 성공!");
                userID = textBoxid.Text;
                form2.userID = userId;
                form2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("로그인 실패! 사용자 ID 또는 비밀번호를 확인하세요.");
            }
        }
    }
}
