﻿namespace M.I.E_alpha_ver._
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBoxengineer = new System.Windows.Forms.CheckBox();
            this.checkBoxdata = new System.Windows.Forms.CheckBox();
            this.checkBoxdevelop = new System.Windows.Forms.CheckBox();
            this.checkBoxsales = new System.Windows.Forms.CheckBox();
            this.checkBoxplan = new System.Windows.Forms.CheckBox();
            this.checkBoxpersonnel = new System.Windows.Forms.CheckBox();
            this.checkBoxmarketing = new System.Windows.Forms.CheckBox();
            this.checkBoxbasic = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBoxexpert = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBoxnewbie = new System.Windows.Forms.CheckBox();
            this.startbutton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.checkBoxengineer);
            this.groupBox1.Controls.Add(this.checkBoxdata);
            this.groupBox1.Controls.Add(this.checkBoxdevelop);
            this.groupBox1.Controls.Add(this.checkBoxsales);
            this.groupBox1.Controls.Add(this.checkBoxplan);
            this.groupBox1.Controls.Add(this.checkBoxpersonnel);
            this.groupBox1.Controls.Add(this.checkBoxmarketing);
            this.groupBox1.Controls.Add(this.checkBoxbasic);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(463, 270);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "면접 직종 선택";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(13, 227);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(371, 34);
            this.label1.TabIndex = 8;
            this.label1.Text = "질문 출처 : 링커리어\r\n(https://community.linkareer.com/employment_data/2647080)";
            // 
            // checkBoxengineer
            // 
            this.checkBoxengineer.AutoSize = true;
            this.checkBoxengineer.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxengineer.Location = new System.Drawing.Point(227, 197);
            this.checkBoxengineer.Name = "checkBoxengineer";
            this.checkBoxengineer.Size = new System.Drawing.Size(140, 27);
            this.checkBoxengineer.TabIndex = 7;
            this.checkBoxengineer.Text = "엔지니어 직무";
            this.checkBoxengineer.UseVisualStyleBackColor = true;
            // 
            // checkBoxdata
            // 
            this.checkBoxdata.AutoSize = true;
            this.checkBoxdata.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxdata.Location = new System.Drawing.Point(227, 147);
            this.checkBoxdata.Name = "checkBoxdata";
            this.checkBoxdata.Size = new System.Drawing.Size(123, 27);
            this.checkBoxdata.TabIndex = 6;
            this.checkBoxdata.Text = "데이터 직무";
            this.checkBoxdata.UseVisualStyleBackColor = true;
            // 
            // checkBoxdevelop
            // 
            this.checkBoxdevelop.AutoSize = true;
            this.checkBoxdevelop.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxdevelop.Location = new System.Drawing.Point(227, 97);
            this.checkBoxdevelop.Name = "checkBoxdevelop";
            this.checkBoxdevelop.Size = new System.Drawing.Size(106, 27);
            this.checkBoxdevelop.TabIndex = 5;
            this.checkBoxdevelop.Text = "개발 직무";
            this.checkBoxdevelop.UseVisualStyleBackColor = true;
            // 
            // checkBoxsales
            // 
            this.checkBoxsales.AutoSize = true;
            this.checkBoxsales.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxsales.Location = new System.Drawing.Point(227, 47);
            this.checkBoxsales.Name = "checkBoxsales";
            this.checkBoxsales.Size = new System.Drawing.Size(106, 27);
            this.checkBoxsales.TabIndex = 4;
            this.checkBoxsales.Text = "영업 직무";
            this.checkBoxsales.UseVisualStyleBackColor = true;
            // 
            // checkBoxplan
            // 
            this.checkBoxplan.AutoSize = true;
            this.checkBoxplan.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxplan.Location = new System.Drawing.Point(16, 197);
            this.checkBoxplan.Name = "checkBoxplan";
            this.checkBoxplan.Size = new System.Drawing.Size(106, 27);
            this.checkBoxplan.TabIndex = 3;
            this.checkBoxplan.Text = "기획 직무";
            this.checkBoxplan.UseVisualStyleBackColor = true;
            // 
            // checkBoxpersonnel
            // 
            this.checkBoxpersonnel.AutoSize = true;
            this.checkBoxpersonnel.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxpersonnel.Location = new System.Drawing.Point(16, 147);
            this.checkBoxpersonnel.Name = "checkBoxpersonnel";
            this.checkBoxpersonnel.Size = new System.Drawing.Size(106, 27);
            this.checkBoxpersonnel.TabIndex = 2;
            this.checkBoxpersonnel.Text = "인사 직무";
            this.checkBoxpersonnel.UseVisualStyleBackColor = true;
            // 
            // checkBoxmarketing
            // 
            this.checkBoxmarketing.AutoSize = true;
            this.checkBoxmarketing.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxmarketing.Location = new System.Drawing.Point(16, 97);
            this.checkBoxmarketing.Name = "checkBoxmarketing";
            this.checkBoxmarketing.Size = new System.Drawing.Size(123, 27);
            this.checkBoxmarketing.TabIndex = 1;
            this.checkBoxmarketing.Text = "마케팅 직무";
            this.checkBoxmarketing.UseVisualStyleBackColor = true;
            // 
            // checkBoxbasic
            // 
            this.checkBoxbasic.AutoSize = true;
            this.checkBoxbasic.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxbasic.Location = new System.Drawing.Point(16, 47);
            this.checkBoxbasic.Name = "checkBoxbasic";
            this.checkBoxbasic.Size = new System.Drawing.Size(66, 27);
            this.checkBoxbasic.TabIndex = 0;
            this.checkBoxbasic.Text = "기본";
            this.checkBoxbasic.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.checkBoxexpert);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.checkBoxnewbie);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(16, 283);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(460, 223);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "면접 방법 선택";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(36, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(357, 40);
            this.label3.TabIndex = 3;
            this.label3.Text = "숙련자 모드는 면접관의 질문이 음성으로만\r\n출력 되어 보다 실제와 비슷한 환경을 구현했습니다.\r\n";
            // 
            // checkBoxexpert
            // 
            this.checkBoxexpert.AutoSize = true;
            this.checkBoxexpert.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxexpert.Location = new System.Drawing.Point(16, 120);
            this.checkBoxexpert.Name = "checkBoxexpert";
            this.checkBoxexpert.Size = new System.Drawing.Size(94, 32);
            this.checkBoxexpert.TabIndex = 2;
            this.checkBoxexpert.Text = "숙련자";
            this.checkBoxexpert.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(36, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "초보자 모드는 면접관의 질문이 텍스트로\r\n출력 되어 보다 답변에 집중할 수 있습니다.";
            // 
            // checkBoxnewbie
            // 
            this.checkBoxnewbie.AutoSize = true;
            this.checkBoxnewbie.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkBoxnewbie.Location = new System.Drawing.Point(16, 37);
            this.checkBoxnewbie.Name = "checkBoxnewbie";
            this.checkBoxnewbie.Size = new System.Drawing.Size(94, 32);
            this.checkBoxnewbie.TabIndex = 0;
            this.checkBoxnewbie.Text = "초보자";
            this.checkBoxnewbie.UseVisualStyleBackColor = true;
            // 
            // startbutton
            // 
            this.startbutton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.startbutton.AutoSize = true;
            this.startbutton.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.startbutton.Location = new System.Drawing.Point(134, 508);
            this.startbutton.Name = "startbutton";
            this.startbutton.Size = new System.Drawing.Size(315, 38);
            this.startbutton.TabIndex = 2;
            this.startbutton.Text = "모의 면접 시작";
            this.startbutton.UseVisualStyleBackColor = true;
            this.startbutton.Click += new System.EventHandler(this.startbutton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 555);
            this.Controls.Add(this.startbutton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxbasic;
        private System.Windows.Forms.CheckBox checkBoxmarketing;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxengineer;
        private System.Windows.Forms.CheckBox checkBoxdata;
        private System.Windows.Forms.CheckBox checkBoxdevelop;
        private System.Windows.Forms.CheckBox checkBoxsales;
        private System.Windows.Forms.CheckBox checkBoxplan;
        private System.Windows.Forms.CheckBox checkBoxpersonnel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBoxnewbie;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxexpert;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button startbutton;
    }
}